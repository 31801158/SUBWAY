package subway;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class DataBuild {
	public static int totalStaion = 0;
	public static int totalLine = 0;
	public static List<Line> lineList=new ArrayList<Line>();
	public static List<Station> stationList=new ArrayList<Station>();//�ظ��治ͬ���ϵ�ͬһ��վ
	public static List<Station> CanTransferStationList=new ArrayList<Station>();//���ظ����ֲ�ͬ���ϵ�ͬһվ
	private static void bulid(){
		try {
			
        	String filePath = "C:/Users/75643/Desktop/������·��Ϣ.txt";
            FileInputStream fin = new FileInputStream(filePath);
            InputStreamReader reader = new InputStreamReader(fin,"UTF-8");//�ַ���
            BufferedReader buffReader = new BufferedReader(reader);
            String strTmp = "";
            while((strTmp = buffReader.readLine())!=null){
            	totalLine++;
            	Line l = new Line();
            	int sid=0;
            	String[] ts=strTmp.split(" ");
            	for(String t:ts) {
            		
            		if((t.charAt(t.length()-1)=='��')||(t.charAt(0)>='1'&&t.charAt(0)<'9')){//����
            			l.setName(t);
            			lineList.add(l);
            			
            		}
            		else{//վ
            			Station s=new Station();
            			s.setName(t);
            			s.setInWhichLine(l);
            			s.addTansferLine(l);
            			s.setId(sid);
            			int i;
            			int circle=0;
            			l.setIsCircle(false);
            			for(i=0;i<l.getOneLineStation().size();i++){
            				if(l.getOneLineStation().get(i).getName().equals(s.getName())){
            					l.setIsCircle(true);
            					circle=1;
            					//System.out.println(l.getName()+"circle");
            					break;
            				}
            			}
            			if(circle==0){
            				for(i=0;i<stationList.size();i++){
            				if(stationList.get(i).getName().equals(t)){//station exist

            					stationList.get(i).addTansferLine(l);
            					stationList.get(i).getInWhichLine().getOneLineStation().set(stationList.get(i).getId(), stationList.get(i));//�����˿ɻ����� ����վ ��ԭ����λ��
            					s.addTansferLine(stationList.get(i).getInWhichLine());
            					if(stationList.get(i).getTansferLine().size()==2)
                					CanTransferStationList.add(s);
            					
            				}
            			}
            				stationList.add(s);
            				l.addOneLineStation(s);
                			sid++;
            			}
            			
            		}
//            		System.out.println(l.getName()+":"+l.getOneLineStation());
            	}
            	
            }
            buffReader.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
	}
	public static void main(String[] args) {
		bulid();
//		for(Line lt:lineList){
//    		System.out.print(lt.getName()+":");
//    		for(Station st:lt.getOneLineStation())
//    			System.out.print(st.getId()+st.getName()+"��"+st.getInWhichLine().getName()+" "+st.getTansferLine().size()+" ");
//    		System.out.println();
//    	}
		
		while(true){
			System.out.println("��ѡ���� ��1�鿴������·��Ϣ��2��ʼ��ѯ·��");
			Scanner input=new Scanner(System.in);
			int chose=input.nextInt();
			if(chose==1){
				for(int i=0;i<lineList.size();i++){
					System.out.println(lineList.get(i).getName());
					for(int j=0;j<lineList.get(i).getOneLineStation().size();j++)
						System.out.print(lineList.get(i).getOneLineStation().get(j).getName()+" ");
					System.out.println();
				}
			}
			else{
				System.out.print("��������ʼվ�����յ�վ�����Կո�ָ���");
			
			String start=input.next();
			
			if(start.equals("exit"))
				break;
			String end=input.next();
			Dijkstra.getRoad(start,end);
			}
			
		}
		
	}
}
