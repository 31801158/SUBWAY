package subway;

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class Dijkstra {
	public static int[][] weight=new int[DataBuild.CanTransferStationList.size()+2][DataBuild.CanTransferStationList.size()+2];
	public static int weightl=DataBuild.CanTransferStationList.size()+2;
	//weight��˳��CanTransferStationList�б���˳��  ֻ����βռ����ͬһ���ϲ��õĵ�
	public static List<Station> result=new ArrayList<Station>();
	public static List<Integer> change=new ArrayList<Integer>();//�ŵ���ÿ��վ��  ǰһ������վ
	public static String resultstring=new String();
	private static int one=-1;
	public static Line inOneLine(Station x,Station y){
		int i;
		int j;
		one=-1;
		Line oneLine=new Line();
		int d=1000;
		for(i=0;i<x.getTansferLine().size();i++){//�������Ƿ���ͬһ������ one
			for(j=0;j<y.getTansferLine().size();j++){
				if(x.getTansferLine().get(i)==y.getTansferLine().get(j)){
					one=1;
					oneLine=x.getTansferLine().get(i);
					for(Station k:oneLine.getOneLineStation()){
						
						if(k.getName().equals(x.getName())&&k.getInWhichLine()==oneLine&&Math.abs(k.getId()-y.getId())<d){
							x=k;
						}
						if(k.getName().equals(y.getName())&&k.getInWhichLine()==oneLine&&Math.abs(x.getId()-k.getId())<d){
							y=k;
						}
					}
					
					if(Math.abs(x.getId()-y.getId())<d){
						d=Math.abs(x.getId()-y.getId());
					}
				}
			}
		}

			return oneLine;	
		
	}
	private static int flagSizeOfW=0;
	public static void buildWeight(Station start,Station end){
		int s=0,e=0;
		
		if(flagSizeOfW==0){//��βվ�����ɻ���
			s=1;e=1;
		}
		else if(flagSizeOfW==1){//����վ������
			e=1;
		}
		else if(flagSizeOfW==2){//��βվ�ɻ���
			s=1;
		}
		else if(flagSizeOfW==3){//���ɻ���
			s=0;e=0;
		}
		//System.out.println("s: "+s+ " e:"+e );
		for(int i=0;i<weightl;i++){
			for(int j=0;j<weight.length;j++)
			weight[i][j]=1000;

		}
		weight[0][0]=0;
		int i,j;
		//0�ŷ�start weightl-1�ŷ�end
		for(i=0+s;i<weightl-e;i++){
			
			weight[i][i]=0;
			for(j=i+1;j<DataBuild.CanTransferStationList.size();j++){//
				if(i==21&&j==55)
				{
					weight[i][i]=0;
				}
				Line l1=inOneLine(DataBuild.CanTransferStationList.get(i),DataBuild.CanTransferStationList.get(j));
				if(one==1){
					int index1=-1,index2=-1;
					for(int k=0;k<l1.getOneLineStation().size();k++){//��վ�� ��l1���ҳ� ��վ
						if(index1!=-1&&index2!=-1)
							break;
						if(l1.getOneLineStation().get(k).getName().equals(DataBuild.CanTransferStationList.get(i).getName())){
							index1=k;
						}
						if(l1.getOneLineStation().get(k).getName().equals(DataBuild.CanTransferStationList.get(j).getName())){
							index2=k;
						}
					}
					if(l1.getIsCircle()){
						weight[i+s][j+s]=weight[j+s][i+s]=Math.min(l1.getOneLineStation().size()-Math.abs(index1-index2),Math.abs(index1-index2));
					}
					else
					weight[i+s][j+s]=weight[j+s][i+s]=Math.abs(index1-index2);
					
				}
			}
		}
		if(s==1){
			for(i=0;i<DataBuild.CanTransferStationList.size();i++){
				Line l1=inOneLine(start,DataBuild.CanTransferStationList.get(i));
				if(one==1){
					int index1=-1,index2=-1;
					for(j=0;j<l1.getOneLineStation().size();j++){
						if(l1.getOneLineStation().get(j).getName().equals(DataBuild.CanTransferStationList.get(i).getName())){
							index1=l1.getOneLineStation().get(j).getId();
						}
						if(l1.getOneLineStation().get(j).getName().equals(start.getName())){
							index2=l1.getOneLineStation().get(j).getId();
						}
					}
					if(l1.getIsCircle()){
						weight[0][1+i]=weight[1+i][0]=Math.min(Math.abs(index1-index2),l1.getOneLineStation().size()-Math.abs(index1-index2));
					}
					else
					weight[0][1+i]=weight[1+i][0]=Math.abs(index1-index2);
				}
			}
			
		}
		if(e==1){
			Line l1=inOneLine(end,DataBuild.CanTransferStationList.get(0));
			if(one==1){
				int index1=-1,index2=-1;
				for(j=0;j<l1.getOneLineStation().size();j++){
					if(l1.getOneLineStation().get(j).getName().equals(DataBuild.CanTransferStationList.get(0).getName())){
						index1=l1.getOneLineStation().get(j).getId();
					}
					if(l1.getOneLineStation().get(j).getName().equals(end.getName())){
						index2=l1.getOneLineStation().get(j).getId();
					}
				}
				if(l1.getIsCircle()){
					weight[weightl-1][0]=weight[0][weightl-1]=Math.min(Math.abs(index1-index2),l1.getOneLineStation().size()-Math.abs(index1-index2));
				}
				else
				weight[weightl-1][0]=weight[0][weightl-1]=Math.abs(index1-index2);	
			}
			for(i=0;i<DataBuild.CanTransferStationList.size();i++){
				l1=inOneLine(end,DataBuild.CanTransferStationList.get(i));
				if(one==1){
					int index1=-1,index2=-1;
					for(j=0;j<l1.getOneLineStation().size();j++){
						if(l1.getOneLineStation().get(j).getName().equals(DataBuild.CanTransferStationList.get(i).getName())){
							index1=l1.getOneLineStation().get(j).getId();
						}
						if(l1.getOneLineStation().get(j).getName().equals(end.getName())){
							index2=l1.getOneLineStation().get(j).getId();
						}
					}
					if(l1.getIsCircle()){
						weight[weightl-1][i+s]=weight[i+s][weightl-1]=Math.min(Math.abs(index1-index2),l1.getOneLineStation().size()-Math.abs(index1-index2));
					}
					else
					weight[weightl-1][i+s]=weight[i+s][weightl-1]=Math.abs(index1-index2);
					
				}
				
			}
		}
		
		
	}
	
	public static void modiWeight(){
		for(int i=0;i<weightl;i++){
			change.add(-1);
		}
		int[] visited=new int[weightl];
		for(int v:visited)
			visited[v]=0;
		visited[0]=1;
		

		for(int i=0;i<weightl;i++){//ÿ��ѭ�� visitedһ����
			int min=1000;
			int posi=0;
			for(int j=1;j<weightl;j++){
				if(visited[j]==0&&weight[0][j]<min){
					min=weight[0][j];
					posi=j;
					
				}
				
			}
			//System.out.println("ѡ��1�����:"+min+" posi:"+posi);
			visited[posi]=1;
			for(int j=0;j<weightl;j++){
				if(weight[0][posi]+weight[posi][j]<weight[0][j]&&j!=posi){
					//System.out.println("ԭ����0��"+j+"��"+weight[0][j]);
					//System.out.println("���£�0��"+j+weight[0][posi]+"+"+weight[posi][j]);
					weight[0][j]=weight[0][posi]+weight[posi][j];
					
					change.set(j, posi);
				}
			}
		}
	}
	public static void getTransfer(int e,Station es){//change
		//System.out.println(flagSizeOfW+"!");
		if(change.get(e)==-1){
			if(flagSizeOfW==3)
			result.add(DataBuild.CanTransferStationList.get(e));
			else if(flagSizeOfW==2)
				result.add(DataBuild.CanTransferStationList.get(e-1));
			else if(flagSizeOfW==1)
				result.add(DataBuild.CanTransferStationList.get(e));
			else{
				result.add(DataBuild.CanTransferStationList.get(e-1));
			}
			return;
		}
		
		if(flagSizeOfW==3){
			getTransfer(change.get(e),es);
			result.add(DataBuild.CanTransferStationList.get(e));
		}
			
		else if(flagSizeOfW==2){//β�ɻ�
			getTransfer(change.get(e),es);
			result.add(DataBuild.CanTransferStationList.get(e-1));
			
		}
		else if(flagSizeOfW==1){//�׿ɻ�
			getTransfer(change.get(e),es);
			if(e<55)
			result.add(DataBuild.CanTransferStationList.get(e));
			else result.add(es);
		}
		else if(flagSizeOfW==0){//�����ɻ���
			getTransfer(change.get(e),es);
			if(e>0&&e<=56){
				result.add(DataBuild.CanTransferStationList.get(e-1));
			}
			else result.add(es);
		} 
	}
	public static void getEveryStation(){
		Line ll2=new Line();
		for(int i=0;i<result.size()-1;i++){
			
			Line ll=inOneLine(result.get(i),result.get(i+1));
			
			int dis;
			int dir;
			for(int j=0;j<DataBuild.stationList.size();j++){
				if(DataBuild.stationList.get(j).getName().equals(result.get(i).getName())&&DataBuild.stationList.get(j).getInWhichLine().getName().equals(ll.getName())){
					result.set(i,DataBuild.stationList.get(j) );
				}
				if(DataBuild.stationList.get(j).getName().equals(result.get(i+1).getName())&&DataBuild.stationList.get(j).getInWhichLine().getName().equals(ll.getName())){
					result.set(i+1,DataBuild.stationList.get(j) );
				}
			}
			int index1=result.get(i).getId(),index2=result.get(i+1).getId();
			if(index1<index2)
				dir=1;
			else dir=-1;
			if(ll.getIsCircle()){
				dis=Math.min(Math.abs(index1-index2),ll.getOneLineStation().size()-Math.abs(index1-index2));
			}
			else
			dis=Math.abs(index1-index2);
			if(i!=0&&ll!=ll2){
			System.out.print("\n(��վ�軻�˵�)"+ll.getName());
			resultstring+="\n(��վ�軻�˵�)"+ll.getName();
			}
			else if(i==0){
				System.out.print("(����)"+ll.getName());
				resultstring+="(����)"+ll.getName();
						}
			
			ll2=ll;
			if(!ll.getIsCircle()){
				for(int j=0;j<dis;j++){
				System.out.print(ll.getOneLineStation().get(index1+(dir)*j).getName()+"->");
				resultstring+=ll.getOneLineStation().get(index1+(dir)*j).getName()+"->";
				}
				System.out.print(ll.getOneLineStation().get(index2).getName());
				resultstring+=ll.getOneLineStation().get(index2).getName();
			}
			else {//����
				dis=Math.min(Math.abs(index1-index2), ll.getOneLineStation().size()-Math.abs(index1-index2));
				if(Math.abs(index1-index2)<=(ll.getOneLineStation().size()-Math.abs(index1-index2))){
					if(index1<index2)
						dir=1;
					else dir=-1;
					for(int j=0;j<dis;j++){
						System.out.print(ll.getOneLineStation().get((index1+(dir)*j)).getName()+"->");
						resultstring+=ll.getOneLineStation().get((index1+(dir)*j)).getName()+"->";
						}
					System.out.print(ll.getOneLineStation().get(index2).getName());
					resultstring+=ll.getOneLineStation().get(index2).getName();
				}
				else {//Ҫ��Խ�ظ�վ
					if(index1<=index2)
						dir=-1;
					else
						dir=1;
				
					if(dir==1){
						for(int j=index1;j<ll.getOneLineStation().size();j++){
							System.out.print(ll.getOneLineStation().get(j).getName()+"->");
							resultstring+=ll.getOneLineStation().get(j).getName()+"->";
							}
						for(int j=0;j<index2;j++){
							System.out.print(ll.getOneLineStation().get((j)).getName()+"->");
						resultstring+=ll.getOneLineStation().get((j)).getName()+"->";}
						System.out.print(ll.getOneLineStation().get((index2)).getName());
						resultstring+=ll.getOneLineStation().get((index2)).getName();
					}
					else{
						for(int j=index1;j>=0;j--){
							System.out.print(ll.getOneLineStation().get(j).getName()+"->");
							resultstring+=ll.getOneLineStation().get(j).getName()+"->";
						}
						for(int j=ll.getOneLineStation().size()-1;j>index2;j--){
							System.out.print(ll.getOneLineStation().get((j)).getName()+"->");
							resultstring+=ll.getOneLineStation().get((j)).getName()+"->";
							}
						System.out.print(ll.getOneLineStation().get((index2)).getName());
						resultstring+=ll.getOneLineStation().get((index2)).getName();
					}
					
					
				}
				
			}
		}
	}
	

static void writefile() throws IOException { 
	FileWriter fileWriter=new FileWriter("C:/Users/75643/Desktop/Result.txt"); 
	fileWriter.write(resultstring+"\n"); 
	fileWriter.flush(); 
	fileWriter.close(); 
}
	
	public static void getRoad(String s,String e){
		weightl=DataBuild.CanTransferStationList.size()+2;
		flagSizeOfW=0;
		one=-1;
		for(int i=0;i<weight.length;i++){
			for(int j=0;j<weight.length;j++)
			weight[i][j]=1000;

		}
		weight[0][0]=0;
		result.clear();
		change.clear();
		int i=0;
		Station start=new Station();
		Station end=new Station();
		int gets=0,gete=0;
		for(i=0;i<DataBuild.stationList.size();i++){
			if(gets==1&&gete==1){
				break;
			}
			if(DataBuild.stationList.get(i).getName().equals(s)){
				start=DataBuild.stationList.get(i);				
				gets=1;
			}
			if(DataBuild.stationList.get(i).getName().equals(e)){
				end=DataBuild.stationList.get(i);
				gete=1;
			}
		}
		if(i>=DataBuild.stationList.size())
		{
			System.out.println("��������!");
			return;
		}
		
		
//		try{
//			System.out.print(start.getName());
//			
//		}catch(NullPointerException exce){
//			System.out.print("�������");
//		}
		//��ȡ����ս βվ��

		
//		for(i=0;i<DataBuild.CanTransferStationList.size();i++)
//			System.out.print(DataBuild.CanTransferStationList.get(i).getName()+" ");
//		System.out.println();
		
		//���� ��βվ�Ƿ�β�ɻ���վ
		for(i=0;i<DataBuild.CanTransferStationList.size();i++){
			if(flagSizeOfW==3)
				break;
			if(start.getName().equals(DataBuild.CanTransferStationList.get(i).getName())&&flagSizeOfW!=1){
				Station t=DataBuild.CanTransferStationList.get(0);
				DataBuild.CanTransferStationList.set(0, DataBuild.CanTransferStationList.get(i));
				DataBuild.CanTransferStationList.set(i, t);
				weightl-=1;
				flagSizeOfW+=1;
			}
			if(end.getName().equals(DataBuild.CanTransferStationList.get(i).getName())&&flagSizeOfW!=2){
				Station t=DataBuild.CanTransferStationList.get(DataBuild.CanTransferStationList.size()-1);
				DataBuild.CanTransferStationList.set(DataBuild.CanTransferStationList.size()-1, DataBuild.CanTransferStationList.get(i));
				DataBuild.CanTransferStationList.set(i, t);
				weightl-=1;
				flagSizeOfW+=2;
			}
		}

//		System.out.println("wei:"+weightl);
//		System.out.println("can:"+DataBuild.CanTransferStationList.size());
		
		buildWeight(start,end);
		
		//�鿴weight����
//		for(i=0;i<weightl;i++){
//			for(int j=0;j<weightl;j++)
//				System.out.print(String.format("%4d ", weight[i][j]));
//			System.out.println();
//		}
		//�鿴cantransferվ��
//		for(i=0;i<DataBuild.CanTransferStationList.size();i++)
//			System.out.print(DataBuild.CanTransferStationList.get(i).getName()+" ");
//		System.out.println(end.getName());
		
		
		result.add(start);
		int s1=0, e1=0;
		if(flagSizeOfW==0){//��βվ�����ɻ���58
			s1=1;e1=1;
		}
		else if(flagSizeOfW==1){//����վ����57
			e1=1;
		}
		else if(flagSizeOfW==2){//��βվ�ɻ���57
			s1=1;
		}
		else if(flagSizeOfW==3){//���ɻ���56
			e1=0;s1=0;
		}
		
		

		modiWeight();
		
		
		
		if(weight[0][weightl-1]==1000){
			System.out.println("��ֱ��·�ߣ�");
			return;
		}
//		for(int j=0;j<weightl;j++)System.out.print(String.format("%4d ", weight[0][j]));		
//			System.out.println();
////		
		if(change.get(weightl-1)==-1){//���û���
			result.add(end);
		}
		else
		getTransfer(weightl-1,end);
//		for(i=0;i<result.size();i++)
//			System.out.print(i+":"+change.get(i)+" ");
//		System.out.println();
		
//		System.out.print("result:");
//		for(i=0;i<result.size();i++)
//			System.out.print(result.get(i).getName()+" ");
//		System.out.println();
		if(end.getName().equals(start.getName())){
			System.out.println("������"+0+"վ");
			resultstring+="������0վ";
		}
		else{
			System.out.println("������"+(weight[0][weightl-1]+1)+"վ");
			resultstring+="������"+(weight[0][weightl-1]+1)+"վ";
		}
		getEveryStation();
		System.out.println();
		resultstring+="\n-------\n";
		try {
			writefile();
		} catch (IOException e2) {
			e2.printStackTrace();
		}
	} 
	
}
