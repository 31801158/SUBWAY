package subway;

import java.util.ArrayList;
import java.util.List;

public class Line {
	private String name;//������
	private List<Station> oneLineStationList=new ArrayList<Station>();//�����ߵ�վ���б�
	private boolean isCircle;//�Ƿ���
	//private List<String> lineName = new ArrayList<>();
	public String getName(){
		return name;
	}
	public void setName(String name){
		this.name=name;
	}
	
	public List<Station> getOneLineStation(){
		return oneLineStationList;
	}
	public void addOneLineStation(Station s){
		oneLineStationList.add(s);
	}
	public boolean getIsCircle(){
		return isCircle;
	}
	public void setIsCircle(boolean c){
		this.isCircle=c;
	}
	
}
